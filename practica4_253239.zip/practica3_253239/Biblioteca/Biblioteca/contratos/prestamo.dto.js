export function aResponseDto(p) {
    return {
        folio: p.folio,
        libroId: p.libroId,
        ejemplares: p.ejemplares,
        socioId: p.socioId,
        estado: p.estado,
        creadoEn: p.creadoEn.toISOString(),
    };
}
