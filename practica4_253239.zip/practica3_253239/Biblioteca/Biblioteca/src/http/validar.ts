import type { CrearPrestamoRequestDto } from '../../contratos/prestamo.dto.js';

export class ValidacionError extends Error {
  constructor(public readonly detalles: string[]) {
    super('Los datos de la peticion no son validos');
    this.name = 'ValidacionError';
  }
}

export function validarCrearPrestamo(datos: unknown): CrearPrestamoRequestDto {
  const errores: string[] = [];

  if (typeof datos !== 'object' || datos === null) {
    throw new ValidacionError(['El cuerpo de la peticion debe ser un objeto']);
  }

  const d = datos as Record<string, unknown>;

  if (typeof d.libroId !== 'string' || d.libroId.trim() === '') {
    errores.push('libroId es obligatorio y debe ser texto');
  }

  if (typeof d.socioId !== 'string' || d.socioId.trim() === '') {
    errores.push('socioId es obligatorio y debe ser texto');
  }

  if (!Array.isArray(d.ejemplares) || d.ejemplares.length === 0) {
    errores.push('ejemplares es obligatorio y debe ser una lista con al menos un elemento');
  } else if (!d.ejemplares.every((e) => typeof e === 'number')) {
    errores.push('todos los ejemplares deben ser numeros');
  }

  if (errores.length > 0) {
    throw new ValidacionError(errores);
  }

  return d as CrearPrestamoRequestDto;
}