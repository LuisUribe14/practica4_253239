import express from 'express';
import { InMemoryPrestamoRepository } from '../infra/in-memory-prestamo.repository.js';
import { PrestamoService } from '../servicios/prestamo.service.js';
import { EjemplarPrestadoError } from '../errores/ejemplar-prestado.error.js';
import { aResponseDto } from '../../contratos/prestamo.dto.js';
import type { ErrorResponseDto } from '../../contratos/prestamo.dto.js';
import { validarCrearPrestamo, ValidacionError } from './validar.js';

const PORT = 3000;

const repositorio = new InMemoryPrestamoRepository();
const servicio = new PrestamoService(repositorio);

const app = express();

app.use(express.json());
app.use(express.static('publico'));

app.get('/api/prestamos', async (req, res) => {
  const libroId = req.query.libroId;

  if (typeof libroId !== 'string' || libroId.trim() === '') {
    const error: ErrorResponseDto = { error: 'Falta el parametro libroId' };
    res.status(400).json(error);
    return;
  }

  const prestamos = await servicio.listarPorLibro(libroId);
  res.status(200).json(prestamos.map(aResponseDto));
});

app.post('/api/prestamos', async (req, res, next) => {
  try {
    const dto = validarCrearPrestamo(req.body);
    const prestamo = await servicio.crear(dto);
    res.status(201).location(`/api/prestamos/${prestamo.folio}`).json(aResponseDto(prestamo));
  } catch (error) {
    next(error);
  }
});

app.use((err: unknown, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  if (err instanceof ValidacionError) {
    const cuerpo: ErrorResponseDto = { error: err.message, detalles: err.detalles };
    res.status(400).json(cuerpo);
    return;
  }

  if (err instanceof EjemplarPrestadoError) {
    const cuerpo: ErrorResponseDto = { error: err.message };
    res.status(409).json(cuerpo);
    return;
  }

  console.error(err);
  const cuerpo: ErrorResponseDto = { error: 'Error interno del servidor' };
  res.status(500).json(cuerpo);
});

app.listen(PORT, () => {
  console.log(`Servidor escuchando en http://localhost:${PORT}`);
});